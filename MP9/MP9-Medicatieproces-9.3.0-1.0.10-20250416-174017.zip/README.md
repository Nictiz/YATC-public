# Nictiz distribution MP9-Medicatieproces-9.3.0 1.0.10

Distribution: MP9-Medicatieproces-9.3.0

Version: 1.0.10

Wijzigingen tov distributie 1.0.7:
- MP-1917 round function met 1 parameter én tekstnodes in xsl variabelen vervangen.


Created: 2025-04-16 17:40:17

This distribution was created by the YATC distribute component.

