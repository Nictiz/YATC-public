<?xml version="1.0" encoding="UTF-8"?>

<!-- == Provenance: YATC-internal/ada-2-fhir-r4/env/zibs/2020/payload/0.11.0-beta.1/nl-core-FluidBalance.xsl == -->
<!-- == Distribution: MP9-Medicatieproces-9.3.0; 1.0.12; 2026-02-13T13:07:12.23+01:00 == -->
<xsl:stylesheet exclude-result-prefixes="#all"
                version="2.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns="http://hl7.org/fhir"
                xmlns:util="urn:hl7:utilities"
                xmlns:f="http://hl7.org/fhir"
                xmlns:nf="http://www.nictiz.nl/functions"
                xmlns:yatcs="https://nictiz.nl/ns/YATC-shared"
                xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
                xmlns:uuid="http://www.uuid.org"
                xmlns:local="#local.2024111408212940601790100">
   <!-- ================================================================== -->
   <!--
        Converts ADA vochtbalans to FHIR Observation resource conforming to profile nl-core-FluidBalance.
    -->
   <!-- ================================================================== -->
   <!--
        Copyright © Nictiz
        
        This program is free software; you can redistribute it and/or modify it under the terms of the
        GNU Lesser General Public License as published by the Free Software Foundation; either version
        2.1 of the License, or (at your option) any later version.
        
        This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
        without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU Lesser General Public License for more details.
        
        The full text of the license is available at http://www.gnu.org/copyleft/lesser.html
    -->
   <!-- ================================================================== -->
   <xsl:output method="xml"
               indent="yes"/>
   <xsl:strip-space elements="*"/>
   <xsl:variable name="profileNameFluidBalance"
                 select="'nl-core-FluidBalance'"/>
   <xsl:variable name="profileNameFluidBalanceFluidTotalIn"
                 select="'nl-core-FluidBalance.FluidTotalIn'"/>
   <xsl:variable name="profileNameFluidBalanceFluidTotalOut"
                 select="'nl-core-FluidBalance.FluidTotalOut'"/>
   <!-- ================================================================== -->
   <xsl:template match="vochtbalans"
                 name="nl-core-FluidBalance"
                 mode="nl-core-FluidBalance"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-FluidBalance instance as an Observation FHIR instance from ADA vochtbalans element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?">
         <!-- Optional ADA instance or ADA reference element for the patient. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameFluidBalance"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="710853006"/>
                  <display value="evaluatie van vochtbalans"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <xsl:if test="vochtbalans_starttijd or vochtbalans_stoptijd">
               <effectivePeriod>
                  <xsl:if test="vochtbalans_starttijd">
                     <start>
                        <xsl:attribute name="value">
                           <xsl:call-template name="format2FHIRDate">
                              <xsl:with-param name="dateTime"
                                              select="xs:string(vochtbalans_starttijd/@value)"/>
                           </xsl:call-template>
                        </xsl:attribute>
                     </start>
                  </xsl:if>
                  <xsl:if test="vochtbalans_stoptijd">
                     <end>
                        <xsl:attribute name="value">
                           <xsl:call-template name="format2FHIRDate">
                              <xsl:with-param name="dateTime"
                                              select="xs:string(vochtbalans_stoptijd/@value)"/>
                           </xsl:call-template>
                        </xsl:attribute>
                     </end>
                  </xsl:if>
               </effectivePeriod>
            </xsl:if>
            <xsl:for-each select="toelichting">
               <note>
                  <text>
                     <xsl:call-template name="string-to-string">
                        <xsl:with-param name="in"
                                        select="."/>
                     </xsl:call-template>
                  </text>
               </note>
            </xsl:for-each>
            <xsl:for-each select="vocht_totaal_in">
               <hasMember>
                  <xsl:call-template name="makeReference">
                     <xsl:with-param name="in"
                                     select="."/>
                     <xsl:with-param name="profile"
                                     select="$profileNameFluidBalanceFluidTotalIn"/>
                  </xsl:call-template>
               </hasMember>
            </xsl:for-each>
            <xsl:for-each select="vocht_totaal_uit">
               <hasMember>
                  <xsl:call-template name="makeReference">
                     <xsl:with-param name="in"
                                     select="."/>
                     <xsl:with-param name="profile"
                                     select="$profileNameFluidBalanceFluidTotalOut"/>
                  </xsl:call-template>
               </hasMember>
            </xsl:for-each>
         </Observation>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="vocht_totaal_in[parent::vochtbalans]"
                 name="nl-core-FluidBalance.FluidTotalIn"
                 mode="nl-core-FluidBalance.FluidTotalIn"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-FluidBalance.FluidTotalIn instance as an Observation FHIR instance from ADA vocht_totaal_in element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?">
         <!-- Optional ADA instance or ADA reference element for the patient. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameFluidBalanceFluidTotalIn"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="251852001"/>
                  <display value="totale vochtinname"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <valueQuantity>
               <xsl:call-template name="hoeveelheid-to-Quantity">
                  <xsl:with-param name="in"
                                  select="."/>
               </xsl:call-template>
            </valueQuantity>
         </Observation>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="vocht_totaal_uit[parent::vochtbalans]"
                 name="nl-core-FluidBalance.FluidTotalOut"
                 mode="nl-core-FluidBalance.FluidTotalOut"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-FluidBalance.FluidTotalOut instance as an Observation FHIR instance from ADA vocht_totaal_uit element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?">
         <!-- Optional ADA instance or ADA reference element for the patient. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameFluidBalanceFluidTotalOut"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="251841007"/>
                  <display value="totale vochtuitscheiding"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <valueQuantity>
               <xsl:call-template name="hoeveelheid-to-Quantity">
                  <xsl:with-param name="in"
                                  select="."/>
               </xsl:call-template>
            </valueQuantity>
         </Observation>
      </xsl:for-each>
   </xsl:template>
</xsl:stylesheet>