<?xml version="1.0" encoding="UTF-8"?>

<!-- == Provenance: YATC-internal/ada-2-fhir-r4/env/zibs/2020/payload/0.10.0-beta.1/nl-core-FeedingPatternInfant.xsl == -->
<!-- == Distribution: MP9-Medicatieproces-9.3.0; 1.0.17; 2026-06-19T14:36:35.72+02:00 == -->
<xsl:stylesheet exclude-result-prefixes="#all"
                version="2.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns="http://hl7.org/fhir"
                xmlns:util="urn:hl7:utilities"
                xmlns:f="http://hl7.org/fhir"
                xmlns:nf="http://www.nictiz.nl/functions"
                xmlns:yatcs="https://nictiz.nl/ns/YATC-shared"
                xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
                xmlns:uuid="http://www.uuid.org"
                xmlns:local="#local.2024111408212883982470100">
   <!-- ================================================================== -->
   <!--
        Converts ADA voedingspatroon_zuigeling to FHIR Observation resource conforming to profile nl-core-FeedingPatternInfant.
    -->
   <!-- ================================================================== -->
   <!--
        Copyright © Nictiz
        
        This program is free software; you can redistribute it and/or modify it under the terms of the
        GNU Lesser General Public License as published by the Free Software Foundation; either version
        2.1 of the License, or (at your option) any later version.
        
        This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
        without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU Lesser General Public License for more details.
        
        The full text of the license is available at http://www.gnu.org/copyleft/lesser.html
    -->
   <!-- ================================================================== -->
   <xsl:output method="xml"
               indent="yes"/>
   <xsl:strip-space elements="*"/>
   <xsl:variable name="profileNameFeedingPatternInfant"
                 select="'nl-core-FeedingPatternInfant'"/>
   <!-- ================================================================== -->
   <xsl:template match="voedingspatroon_zuigeling"
                 name="nl-core-FeedingPatternInfant"
                 mode="nl-core-FeedingPatternInfant"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-FeedingPatternInfant instance as an Observation FHIR instance from ADA voedingspatroon_zuigeling element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?"/>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameFeedingPatternInfant"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <xsl:for-each select="voedingsadvies">
               <basedOn>
                  <xsl:call-template name="makeReference">
                     <xsl:with-param name="in"
                                     select="voedingsadvies"/>
                     <xsl:with-param name="profile"
                                     select="$profileNameNutritionAdvice"/>
                  </xsl:call-template>
               </basedOn>
            </xsl:for-each>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="289145007"/>
                  <display value="bevinding betreffende voedingspatroon van zuigeling"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <xsl:for-each select="voedingspatroon_zuigeling_datum_tijd">
               <effectiveDateTime>
                  <xsl:call-template name="date-to-datetime">
                     <xsl:with-param name="in"
                                     select="."/>
                  </xsl:call-template>
               </effectiveDateTime>
            </xsl:for-each>
            <xsl:for-each select="toelichting">
               <note>
                  <text>
                     <xsl:call-template name="string-to-string">
                        <xsl:with-param name="in"
                                        select="."/>
                     </xsl:call-template>
                  </text>
               </note>
            </xsl:for-each>
            <xsl:for-each select="voeding_toevoeging">
               <component>
                  <code>
                     <coding>
                        <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                        <code value="373453009"/>
                        <display value="voedingssupplement"/>
                     </coding>
                  </code>
                  <valueString>
                     <xsl:call-template name="string-to-string">
                        <xsl:with-param name="in"
                                        select="."/>
                     </xsl:call-template>
                  </valueString>
               </component>
            </xsl:for-each>
            <xsl:for-each select="voeding_frequentie">
               <component>
                  <code>
                     <coding>
                        <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                        <code value="364653007"/>
                        <display value="frequentie van voeding van zuigeling"/>
                     </coding>
                  </code>
                  <valueQuantity>
                     <xsl:call-template name="hoeveelheid-to-Quantity">
                        <xsl:with-param name="in"
                                        select="."/>
                     </xsl:call-template>
                  </valueQuantity>
               </component>
            </xsl:for-each>
            <xsl:for-each select="voeding">
               <component>
                  <xsl:for-each select="voeding_methode">
                     <extension url="http://nictiz.nl/fhir/StructureDefinition/ext-FeedingPatternInfant.FeedingMethod">
                        <valueCodeableConcept>
                           <xsl:call-template name="code-to-CodeableConcept">
                              <xsl:with-param name="in"
                                              select="."/>
                           </xsl:call-template>
                        </valueCodeableConcept>
                     </extension>
                  </xsl:for-each>
                  <code>
                     <coding>
                        <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                        <code value="109021000146107"/>
                        <display value="soort zuigelingenvoeding"/>
                     </coding>
                  </code>
                  <xsl:for-each select="voeding_soort">
                     <valueCodeableConcept>
                        <xsl:call-template name="code-to-CodeableConcept">
                           <xsl:with-param name="in"
                                           select="."/>
                        </xsl:call-template>
                     </valueCodeableConcept>
                  </xsl:for-each>
               </component>
            </xsl:for-each>
         </Observation>
      </xsl:for-each>
   </xsl:template>
</xsl:stylesheet>