<?xml version="1.0" encoding="UTF-8"?>

<!-- == Provenance: YATC-internal/ada-2-hl7/env/mp/9.3.0/2_hl7_mp_include_930.xsl == -->
<!-- == Distribution: MP9-Medicatieproces-9.3.0; 1.0.17; 2026-06-23T09:09:23.28+02:00 == -->
<xsl:stylesheet exclude-result-prefixes="#all"
                version="2.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns="urn:hl7-org:v3"
                xmlns:yatcs="https://nictiz.nl/ns/YATC-shared"
                xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
                xmlns:local="#local.2024011810474750857820100"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xmlns:hl7="urn:hl7-org:v3"
                xmlns:util="urn:hl7:utilities"
                xmlns:sdtc="urn:hl7-org:sdtc"
                xmlns:nf="http://www.nictiz.nl/functions"
                xmlns:hl7nl="urn:hl7-nl:v3"
                xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:pharm="urn:ihe:pharm:medication">
   <!-- ================================================================== -->
   <!--
        TBD
    -->
   <!-- ================================================================== -->
   <!--
        Copyright © Nictiz
        
        This program is free software; you can redistribute it and/or modify it under the terms of the
        GNU Lesser General Public License as published by the Free Software Foundation; either version
        2.1 of the License, or (at your option) any later version.
        
        This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
        without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU Lesser General Public License for more details.
        
        The full text of the license is available at http://www.gnu.org/copyleft/lesser.html
    -->
   <!-- ================================================================== -->
   <xsl:import href="../../../common/includes/2_hl7_mp_include.xsl"/>
   <xsl:import href="../../../common/includes/ada2hl7_all-zibs-d655e329.xsl"/>
   <!-- these imports are needed to handle the FHIR Timing datatype in HL7v3 substanceAdministration -->
   <xsl:import href="../../../common/includes/mp-functions-fhir.xsl"/>
   <xsl:import href="../../../common/includes/mp-functions-hl7v3-fhir.xsl"/>
   <xsl:import href="../../../ada_2_fhir-r4/mp/9.3.0/payload/mp9_latest_package.xsl"/>
   <xsl:param name="logLevel"
              select="$logINFO"
              as="xs:string"/>
   <!-- ============================================================= -->
   <!-- Helper functions for transaction-scoped bouwstenen resolution -->
   <!-- Works for any transaction type, batch-safe                   -->
   <!-- ============================================================= -->
   <xsl:function name="local:txRoot"
                 as="element()?">
      <xsl:param name="n"
                 as="node()"/>
      <!-- nearest ancestor-or-self that contains a child <bouwstenen> -->
      <xsl:sequence select="($n/ancestor-or-self::*[child::bouwstenen])[1]"/>
   </xsl:function>
   <xsl:function name="local:bouwstenen"
                 as="element()?">
      <xsl:param name="n"
                 as="node()"/>
      <xsl:sequence select="local:txRoot($n)/bouwstenen"/>
   </xsl:function>
   <!-- ================================================================== -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9357_2021002133425">
      <!-- Financiële indicatiecode -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ada element to be converted, defaults to context -->
      </xsl:param>
      <xsl:for-each select="$in">
         <observation classCode="OBS"
                      moodCode="EVN">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9357"/>
            <code displayName="Drug prescription for reimbursement (finding)"
                  codeSystemName="SNOMED CT"
                  code="153931000146103"
                  codeSystem="2.16.840.1.113883.6.96"/>
            <xsl:call-template name="makeCEValue"/>
         </observation>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9406_20221101091730"
                 match="medicatietoediening">
      <!-- Mapping of medicatietoediening concept in ADA to HL7 -->
      <xsl:param name="in"
                 select=".">
         <!-- ADA Node to consider in the creation of the hl7 element -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="EVN">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9406"/>
            <xsl:for-each select="identificatie[.//(@value | @code)]">
               <xsl:call-template name="makeIIid"/>
            </xsl:for-each>
            <code code="18629005"
                  displayName="toediening van medicatie (verrichting)"
                  codeSystem="{$oidSNOMEDCT}"
                  codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
            <!-- statusCode: voor foutcorrectie -->
            <xsl:if test="geannuleerd_indicator/@value = 'true'">
               <statusCode code="nullified"/>
            </xsl:if>
            <!-- toedienings_datum_tijd -->
            <xsl:for-each select="toedienings_datum_tijd[@value | @nullFlavor]">
               <effectiveTime>
                  <xsl:call-template name="makeTSValueAttr"/>
               </effectiveTime>
            </xsl:for-each>
            <!-- toedieningsweg -->
            <xsl:for-each select="toedieningsweg[(@value | @code | @nullFlavor)]">
               <routeCode>
                  <xsl:call-template name="makeCodeAttribs"/>
               </routeCode>
            </xsl:for-each>
            <!-- prik_plak_locatie -->
            <xsl:choose>
               <xsl:when test="prik_plak_locatie/anatomische_locatie/*">
                  <xsl:for-each select="prik_plak_locatie/anatomische_locatie[(locatie | lateraliteit)[@code]]">
                     <approachSiteCode>
                        <xsl:for-each select="(locatie[@code])[1]">
                           <xsl:call-template name="makeCodeAttribs"/>
                        </xsl:for-each>
                        <xsl:for-each select="(lateraliteit[@code])[1]">
                           <qualifier>
                              <name code="272741003"
                                    codeSystem="{$oidMap[@oid = $oidSNOMEDCT]/@oid}"
                                    codeSystemName="{$oidMap[@oid = $oidSNOMEDCT]/@displayName}"
                                    displayName="Lateraliteit"/>
                              <xsl:call-template name="makeCDValue"/>
                           </qualifier>
                        </xsl:for-each>
                     </approachSiteCode>
                  </xsl:for-each>
               </xsl:when>
               <!-- legacy pre mp9 3.0-beta.3 -->
               <xsl:when test="prik_plak_locatie[@value]">
                  <xsl:for-each select="prik_plak_locatie[@value]">
                     <approachSiteCode nullFlavor="OTH">
                        <originalText>
                           <xsl:value-of select="@value"/>
                        </originalText>
                     </approachSiteCode>
                  </xsl:for-each>
               </xsl:when>
            </xsl:choose>
            <!-- toegediende_hoeveelheid -->
            <xsl:for-each select="toegediende_hoeveelheid[.//(@value | @code)]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9048_20160614145840"/>
            </xsl:for-each>
            <!-- toedieningssnelheid -->
            <xsl:for-each select="toedieningssnelheid[.//(@value | @code)]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9150_20160726150449"/>
            </xsl:for-each>
            <!-- toedienings_product backward compatible -->
            <xsl:for-each select="(local:bouwstenen(current())/farmaceutisch_product[@id = current()/toedienings_product/farmaceutisch_product/@value])[1]">
               <consumable>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9362_20210602154632">
                     <xsl:with-param name="product"
                                     select="."/>
                  </xsl:call-template>
               </consumable>
            </xsl:for-each>
            <!-- toediener -->
            <xsl:for-each select="toediener">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9407_20221101101151"/>
            </xsl:for-each>
            <!-- registratieDatumTijd -->
            <xsl:variable name="mtdRegistratieDatumTijd"
                          select="registratie_datum_tijd[@value | @nullFlavor]"
                          as="element()*"/>
            <xsl:if test="$mtdRegistratieDatumTijd instance of element()">
               <author>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.32_20210701000000">
                     <!-- we don't have an author in MTD, but need an element in $in to make the mandatory xsd elements -->
                     <xsl:with-param name="in"
                                     select="$mtdRegistratieDatumTijd[1]"/>
                     <xsl:with-param name="theTime"
                                     select="$mtdRegistratieDatumTijd[1]"/>
                  </xsl:call-template>
               </author>
            </xsl:if>
            <!-- afgesproken_datum_tijd en/of afgesproken_hoeveelheid -->
            <xsl:if test="afgesproken_datum_tijd[@value] | afgesproken_hoeveelheid[.//(@value | @code | @unit)]">
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9376_20210617000000">
                     <xsl:with-param name="datumTijdElement"
                                     select="afgesproken_datum_tijd[@value]"/>
                     <xsl:with-param name="keerdosisElement"
                                     select="afgesproken_hoeveelheid[.//(@value | @code | @unit)]"/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:if>
            <!-- MP-1393, remove volgens_afspraak_indicator / afwijkende_toediening -->
            <!-- medicatietoediening_reden_van_afwijken -->
            <xsl:for-each select="(medicatie_toediening_reden_van_afwijken | medicatietoediening_reden_van_afwijken)[.//(@value | @code)]">
               <entryRelationship typeCode="RSON">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9375_20210616173557"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- toelichting -->
            <xsl:for-each select="toelichting[.//(@value | @code)]">
               <entryRelationship typeCode="SUBJ"
                                  inversionInd="true">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- Relatie naar MA -->
            <xsl:for-each select="relatie_medicatieafspraak/identificatie[@value | @nullFlavor]">
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                     <xsl:with-param name="identificatieElement"
                                     select="."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!-- Relatie naar TA -->
            <xsl:for-each select="relatie_toedieningsafspraak/identificatie[@value | @nullFlavor]">
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9101_20160624130316">
                     <xsl:with-param name="identificatieElement"
                                     select="."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!-- Relatie naar WDS -->
            <xsl:for-each select="relatie_wisselend_doseerschema/identificatie[@value | @nullFlavor]">
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9381_20210617181505">
                     <xsl:with-param name="identificatieElement"
                                     select="."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!--Relatie naar medicamenteuze behandeling-->
            <entryRelationship typeCode="COMP"
                               inversionInd="true">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
                  <xsl:with-param name="MBHroot"
                                  select=".."/>
               </xsl:call-template>
            </entryRelationship>
            <!-- relaties huisartsenzorg -->
            <xsl:for-each select="relatie_contact/identificatienummer[@value | @nullFlavor]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.32_20171221123947"/>
            </xsl:for-each>
            <xsl:for-each select="relatie_zorgepisode/identificatienummer[@value | @nullFlavor]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.33_20171221124050"/>
            </xsl:for-each>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9407_20221101101151"
                 match="toediener"
                 mode="HandleToediener92">
      <!-- Toediener in medicatietoediening -->
      <xsl:param name="in"
                 as="element()*"
                 select=".">
         <!-- the ada element for toediener, defaults to context -->
      </xsl:param>
      <xsl:for-each select="$in">
         <!-- patient -->
         <xsl:for-each select="patient[not(toediener_is_patient/@value = 'false')][.//@value]">
            <performer>
               <!-- temp workaround for MP-1351, add time with nullFlavor -->
               <time nullFlavor="NI"/>
               <assignedEntity>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.52_20170825000000">
                     <xsl:with-param name="ada_patient_identificatienummer"
                                     select="ancestor::data/*/patient/identificatienummer"/>
                  </xsl:call-template>
               </assignedEntity>
            </performer>
         </xsl:for-each>
         <!-- MP-1417, revert changes done bij MP-616, so re-add support for toediener/zorgverlener -->
         <!-- zorgverlener -->
         <xsl:for-each select="local:bouwstenen(current())/zorgverlener[@id = current()//zorgverlener[not(zorgverlener)]/@value]">
            <performer>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.43_20210701000000"/>
            </performer>
         </xsl:for-each>
         <!-- zorgaanbieder is toediener, even though this is not specified anymore with MP-1417 in beta.3 the mapping still supports this for backward compatibility reasons, 
                goal is to minimise possible data loss -->
         <xsl:for-each select="local:bouwstenen(current())/zorgaanbieder[@id = current()//zorgaanbieder[not(zorgaanbieder)]/@value]">
            <performer>
               <assignedEntity>
                  <!-- id is required in xsd, but no use for it when only communicating zorgaanbieder -->
                  <id nullFlavor="NI"/>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.33_20210701000000"/>
               </assignedEntity>
            </performer>
         </xsl:for-each>
         <!-- mantelzorger -->
         <xsl:for-each select="local:bouwstenen(current())/contactpersoon[@id = current()/mantelzorger/contactpersoon/@value]">
            <performer>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.44_20210701000000"/>
            </performer>
         </xsl:for-each>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9412_20221118130922"
                 match="wisselend_doseerschema">
      <!-- Mapping of wisselend_doseerschema concept in ADA to HL7 CDA template -->
      <xsl:param name="in"
                 select=".">
         <!-- ADA Node to consider in the creation of the hl7 element -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9412"/>
            <xsl:for-each select="identificatie[.//(@value | @code)]">
               <xsl:call-template name="makeIIid"/>
            </xsl:for-each>
            <code code="395067002"
                  displayName="optimaliseren van dosering van medicatie (verrichting)"
                  codeSystem="{$oidSNOMEDCT}"
                  codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
            <!-- gebruiksinstructie/omschrijving -->
            <xsl:call-template name="makeInstructionText"/>
            <!-- Gebruiksperiode -->
            <xsl:call-template name="_handleGebruiksperiode"/>
            <xsl:for-each select="gebruiksinstructie/toedieningsweg[.//(@value | @code)]">
               <routeCode>
                  <xsl:call-template name="makeCodeAttribs"/>
               </routeCode>
            </xsl:for-each>
            <!-- backward compatible -->
            <xsl:for-each select="(local:bouwstenen(current())/farmaceutisch_product[@id = current()/afgesproken_geneesmiddel/farmaceutisch_product/@value])[1]">
               <consumable>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9362_20210602154632">
                     <xsl:with-param name="product"
                                     select="."/>
                  </xsl:call-template>
               </consumable>
            </xsl:for-each>
            <xsl:variable name="wdsRegistratieDatumTijd"
                          select="registratie_datum_tijd[@value | @nullFlavor]"
                          as="element()*"/>
            <!-- give precedence to the new registration date/time, but don't remove support for afspraak datum/tijd if it's there -->
            <xsl:variable name="wdsDatumTijd"
                          select="                         if ($wdsRegistratieDatumTijd instance of element()) then                             $wdsRegistratieDatumTijd                         else                             wisselend_doseerschema_datum_tijd[@value | @nullFlavor]"
                          as="element()*"/>
            <xsl:variable name="wdsAuthor"
                          select="local:bouwstenen(current())/zorgverlener[@id = current()/auteur/zorgverlener/@value]"
                          as="element()*"/>
            <xsl:if test="$wdsDatumTijd | $wdsAuthor">
               <author>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.32_20210701000000">
                     <xsl:with-param name="in"
                                     select="$wdsAuthor[1]"/>
                     <xsl:with-param name="theTime"
                                     select="$wdsDatumTijd[1]"/>
                  </xsl:call-template>
               </author>
            </xsl:if>
            <!-- stoptype -->
            <xsl:for-each select="wisselend_doseerschema_stop_type[.//(@value | @code)]">
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9414_20221118141506"/>
               </entryRelationship>
            </xsl:for-each>
            <xsl:for-each select="(reden_wijzigen_of_staken)[.//(@value | @code)]">
               <entryRelationship typeCode="RSON">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9439_20221124114130"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- aanvullende instructie -->
            <xsl:for-each select="gebruiksinstructie/aanvullende_instructie[.//(@value | @code)]">
               <entryRelationship typeCode="SPRT">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9085_20160621114818">
                     <xsl:with-param name="ada-aanvullende-instructie"
                                     select="."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!-- toelichting -->
            <xsl:for-each select="toelichting[.//(@value | @code)]">
               <entryRelationship typeCode="SUBJ"
                                  inversionInd="true">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
               </entryRelationship>
            </xsl:for-each>
            <!--Doseerinstructie-->
            <xsl:for-each select="gebruiksinstructie/doseerinstructie[.//(@value | @code | @nullFlavor)]">
               <xsl:call-template name="_handleDoseerinstructie"/>
            </xsl:for-each>
            <!-- Relatie naar MA -->
            <xsl:for-each select="relatie_medicatieafspraak/identificatie[@value | @nullFlavor]">
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                     <xsl:with-param name="identificatieElement"
                                     select="."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!-- Relatie naar WDS -->
            <xsl:for-each select="relatie_wisselend_doseerschema/identificatie[@value | @nullFlavor]">
               <!-- kunnen er 0 of 1 zijn -->
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9381_20210617181505">
                     <xsl:with-param name="identificatieElement"
                                     select="."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!-- Kopie-indicator -->
            <xsl:if test="kopie_indicator">
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9200_20180112101847">
                     <xsl:with-param name="kopie-ind"
                                     select="kopie_indicator"/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:if>
            <!--Relatie naar medicamenteuze behandeling-->
            <entryRelationship typeCode="COMP"
                               inversionInd="true">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
                  <xsl:with-param name="MBHroot"
                                  select=".."/>
               </xsl:call-template>
            </entryRelationship>
            <!-- relaties huisartsenzorg -->
            <xsl:for-each select="relatie_contact/identificatienummer[@value | @nullFlavor]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.32_20171221123947"/>
            </xsl:for-each>
            <xsl:for-each select="relatie_zorgepisode/identificatienummer[@value | @nullFlavor]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.33_20171221124050"/>
            </xsl:for-each>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9414_20221118141506">
      <!-- Stoptype -->
      <observation classCode="OBS"
                   moodCode="EVN">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9414"/>
         <code code="1"
               displayName="Stoptype"
               codeSystem="2.16.840.1.113883.2.4.3.11.60.20.77.5.2"
               codeSystemName="Medicatieproces observaties"/>
         <xsl:call-template name="makeCEValue"/>
      </observation>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9415_20221121070356"
                 match="toedieningsafspraak"
                 mode="HandleTAContents910">
      <!--  Toedieningsafspraak inhoud vanaf 9.1.0 -->
      <xsl:param name="in">
         <!-- ada input element -->
      </xsl:param>
      <xsl:for-each select="$in">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9415"/>
         <xsl:for-each select="identificatie[@value | @root]">
            <xsl:call-template name="makeIIid"/>
         </xsl:for-each>
         <code code="422037009"
               displayName="Toedieningsafspraak"
               codeSystem="{$oidSNOMEDCT}"
               codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
         <!-- gebruiksinstructie/omschrijving -->
         <xsl:call-template name="makeInstructionText"/>
         <!-- statusCode: voor foutcorrectie -->
         <xsl:if test="geannuleerd_indicator/@value = 'true'">
            <statusCode code="nullified"/>
         </xsl:if>
         <!-- Gebruiksperiode -->
         <xsl:call-template name="_handleGebruiksperiode"/>
         <!-- toedieningsweg -->
         <xsl:for-each select="gebruiksinstructie/toedieningsweg[@code]">
            <routeCode>
               <xsl:call-template name="makeCodeAttribs"/>
            </routeCode>
         </xsl:for-each>
         <!-- geneesmiddel_bij_toedieningsafspraak en backward compatible-->
         <xsl:for-each select="(local:bouwstenen(current())/farmaceutisch_product[@id = current()/geneesmiddel_bij_toedieningsafspraak/farmaceutisch_product/@value])[1]">
            <consumable>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9362_20210602154632">
                  <xsl:with-param name="product"
                                  select="."/>
               </xsl:call-template>
            </consumable>
         </xsl:for-each>
         <!-- Verstrekker -->
         <xsl:variable name="taRegistratieDatumTijd"
                       select="registratie_datum_tijd[@value | @nullFlavor]"
                       as="element()*"/>
         <!-- give precedence to the new registration date/time, but don't remove support for afspraak datum/tijd if it's there -->
         <xsl:variable name="taDatumTijd"
                       select="                     if ($taRegistratieDatumTijd instance of element()) then                         $taRegistratieDatumTijd                     else                         (afspraak_datum_tijd | afspraakdatum | toedieningsafspraak_datum_tijd)[@value | @nullFlavor]"
                       as="element()*"/>
         <xsl:for-each select="local:bouwstenen(current())/zorgaanbieder[@id = current()/verstrekker/zorgaanbieder/@value]">
            <author>
               <xsl:call-template name="makeTSValue">
                  <xsl:with-param name="elemName">time</xsl:with-param>
                  <xsl:with-param name="inputValue"
                                  select="$taDatumTijd/@value"/>
                  <xsl:with-param name="inputNullFlavor"
                                  select="$taDatumTijd/@nullFlavor"/>
               </xsl:call-template>
               <assignedAuthor>
                  <id nullFlavor="NI"/>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.33_20210701000000"/>
               </assignedAuthor>
            </author>
         </xsl:for-each>
         <!-- stoptype -->
         <xsl:for-each select="(toedieningsafspraak_stop_type | stoptype)[@code]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9414_20221118141506"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- reden_afspraak, with MP-369 name change to toedieningsafspraak_reden_wijzigen_of_staken -->
         <xsl:for-each select="(reden_afspraak | toedieningsafspraak_reden_wijzigen_of_staken)[@value][not(@code)]">
            <entryRelationship typeCode="RSON">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9315_20200120125612"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- reden_afspraak, with MP-370 type change from string to code -->
         <xsl:for-each select="(reden_afspraak | toedieningsafspraak_reden_wijzigen_of_staken)[@code]">
            <entryRelationship typeCode="RSON">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9440_20221124114649"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- aanvullende_instructie -->
         <xsl:for-each select="gebruiksinstructie/aanvullende_instructie[.//(@value | @code)]">
            <entryRelationship typeCode="SPRT">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9085_20160621114818">
                  <xsl:with-param name="ada-aanvullende-instructie"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- distributievorm -->
         <xsl:for-each select="distributievorm[.//(@value | @code | @nullFlavor)]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9097_20160623203415"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- aanvullende informatie -->
         <xsl:for-each select="(aanvullende_informatie | toedieningsafspraak_aanvullende_informatie)[@value | @code]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9402_20220315000000"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Toelichting -->
         <xsl:for-each select="toelichting">
            <entryRelationship typeCode="SUBJ"
                               inversionInd="true">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
            </entryRelationship>
         </xsl:for-each>
         <!--Doseerinstructie-->
         <xsl:for-each select="gebruiksinstructie/doseerinstructie[.//(@value | @code | @nullFlavor)]">
            <xsl:call-template name="_handleDoseerinstructie"/>
         </xsl:for-each>
         <!-- Kopie-indicator -->
         <xsl:if test="kopie_indicator">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9200_20180112101847">
                  <xsl:with-param name="kopie-ind"
                                  select="kopie_indicator"/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:if>
         <!-- relatie naar MA -->
         <xsl:for-each select="(relatie_naar_medicatieafspraak | relatie_medicatieafspraak)[identificatie[@value | @nullFlavor]]">
            <!-- kunnen er 0 of meer zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                  <xsl:with-param name="identificatieElement"
                                  select="identificatie"/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- relatie naar TA -->
         <xsl:for-each select="(relatie_toedieningsafspraak)[identificatie[@value | @nullFlavor]]">
            <!-- kunnen er 0 of meer zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9101_20160624130316">
                  <xsl:with-param name="identificatieElement"
                                  select="identificatie"/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!--Relatie naar medicamenteuze behandeling-->
         <entryRelationship typeCode="COMP"
                            inversionInd="true">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
               <xsl:with-param name="MBHroot"
                               select=".."/>
            </xsl:call-template>
         </entryRelationship>
         <!-- gebruiksperiode/criterium -->
         <xsl:for-each select="gebruiksperiode/criterium[@value]">
            <precondition>
               <criterion>
                  <text mediaType="plain/text">
                     <xsl:value-of select="@value"/>
                  </text>
               </criterion>
            </precondition>
         </xsl:for-each>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9416_20221121074758"
                 match="toedieningsafspraak"
                 mode="HandleTA920">
      <!-- Toedieningsafspraak vanaf 9.2.0 -->
      <xsl:param name="in"
                 select=".">
         <!-- ada Toedieningsafspraak -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9416"/>
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9415_20221121070356">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9417_20221121085549"
                 match="toedieningsafspraak"
                 mode="HandleTAKopie920">
      <!-- Toedieningsafspraak vanaf 9.3.0 - kopie -->
      <xsl:param name="in"
                 select=".">
         <!-- ada Toedieningsafspraak -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9327"/>
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9415_20221121070356">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9427_20221122115521"
                 match="medicatieafspraak">
      <!-- Template for Medicatieafspraak resuable parts 1 for MP 9 2.0. SNOMED code update -->
      <!-- MP CDA Medicatieafspraak onderdelen 1 -->
      <xsl:for-each select="identificatie[.//(@value | @code)]">
         <xsl:call-template name="makeIIid"/>
      </xsl:for-each>
      <code code="33633005"
            displayName="voorschrijven van geneesmiddel (verrichting)"
            codeSystem="{$oidSNOMEDCT}"
            codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
      <!-- gebruiksinstructie/omschrijving -->
      <xsl:call-template name="makeInstructionText"/>
      <!-- statusCode: voor foutcorrectie -->
      <!-- uitgefaseerd in 9 1.0, opnieuw toegevoegd in 9.2.0 -->
      <xsl:if test="geannuleerd_indicator/@value = 'true'">
         <statusCode code="nullified"/>
      </xsl:if>
      <!-- Gebruiksperiode -->
      <xsl:call-template name="_handleGebruiksperiode"/>
      <xsl:for-each select="gebruiksinstructie/toedieningsweg[.//(@value | @code)]">
         <routeCode>
            <xsl:call-template name="makeCodeAttribs"/>
         </routeCode>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9428_20221122124407">
      <!--  MP CDA (proposition) medication agreement ( (voorstel) Medicatieafspraak) reusable part -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- The input ada medication agreement, defaults to context -->
      </xsl:param>
      <xsl:for-each select="$in">
         <xsl:for-each select="(stoptype | medicatieafspraak_stop_type)[.//(@value | @code)]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9414_20221118141506"/>
            </entryRelationship>
         </xsl:for-each>
         <xsl:for-each select="(reden_afspraak | reden_wijzigen_of_staken)[.//(@value | @code)]">
            <entryRelationship typeCode="RSON">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9438_20221124113046"/>
            </entryRelationship>
         </xsl:for-each>
         <xsl:for-each select="reden_van_voorschrijven/probleem[probleem_naam[.//(@value | @code | @nullFlavor | @originalText)]]">
            <entryRelationship typeCode="RSON">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.24_20210701000000"/>
            </entryRelationship>
         </xsl:for-each>
         <xsl:for-each select="gebruiksinstructie/aanvullende_instructie[.//(@value | @code)]">
            <entryRelationship typeCode="SPRT">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9085_20160621114818">
                  <xsl:with-param name="ada-aanvullende-instructie"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- aanvullende_informatie, MP-536 new template in MP9 2.0.0 -->
         <xsl:for-each select="aanvullende_informatie[@value | @code]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9401_20220315000000"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- toelichting -->
         <xsl:for-each select="toelichting[.//(@value | @code)]">
            <entryRelationship typeCode="SUBJ"
                               inversionInd="true">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
            </entryRelationship>
         </xsl:for-each>
         <!--Doseerinstructie-->
         <xsl:for-each select="gebruiksinstructie/doseerinstructie[.//(@value | @code | @nullFlavor)]">
            <xsl:call-template name="_handleDoseerinstructie"/>
         </xsl:for-each>
         <!-- Relatie naar MA -->
         <xsl:for-each select="(relatie_naar_afspraak_of_gebruik | relatie_medicatieafspraak)/identificatie[@value | @nullFlavor]">
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                  <xsl:with-param name="identificatieElement"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- Relatie naar TA -->
         <xsl:for-each select="(relatie_naar_afspraak_of_gebruik/identificatie_23288 | relatie_toedieningsafspraak/identificatie)[@value | @nullFlavor]">
            <!-- kunnen er 0 of 1 zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9101_20160624130316">
                  <xsl:with-param name="identificatieElement"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- Relatie naar GB -->
         <xsl:for-each select="(relatie_naar_afspraak_of_gebruik/identificatie_23289 | relatie_medicatiegebruik/identificatie)[@value | @nullFlavor]">
            <!-- kunnen er 0 of 1 zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9386_20210629170021">
                  <xsl:with-param name="identificatieElement"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9429_20221122130054">
      <!--  Medicatieafspraak inhoud - vanaf MP 9.2 -->
      <xsl:param name="in"
                 select=".">
         <!-- Input ada element for medicatieafspraak -->
      </xsl:param>
      <xsl:for-each select="$in">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9429"/>
         <!-- MA Onderdelen 1 -->
         <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9427_20221122115521"/>
         <!-- backward compatible -->
         <xsl:for-each select="(local:bouwstenen(current())/farmaceutisch_product                 [@id = current()/afgesproken_geneesmiddel/farmaceutisch_product/@value])[1]">
            <consumable>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9362_20210602154632">
                  <xsl:with-param name="product"
                                  select="."/>
               </xsl:call-template>
            </consumable>
         </xsl:for-each>
         <xsl:variable name="maRegistratieDatumTijd"
                       select="registratie_datum_tijd[@value | @nullFlavor]"
                       as="element()*"/>
         <!-- give precedence to the new registration date/time, but don't remove support for afspraak datum/tijd if it's there -->
         <xsl:variable name="maDatumTijd"
                       select="                     if ($maRegistratieDatumTijd instance of element()) then                         $maRegistratieDatumTijd                     else                         (afspraak_datum_tijd | afspraakdatum | medicatieafspraak_datum_tijd)[@value | @nullFlavor]"
                       as="element()*"/>
         <xsl:variable name="maAuthor"
                       select="local:bouwstenen(current())/zorgverlener[@id = current()/voorschrijver/zorgverlener/@value]"
                       as="element()*"/>
         <xsl:if test="$maDatumTijd | $maAuthor">
            <author>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.32_20210701000000">
                  <xsl:with-param name="in"
                                  select="$maAuthor[1]"/>
                  <xsl:with-param name="theTime"
                                  select="$maDatumTijd[1]"/>
               </xsl:call-template>
            </author>
         </xsl:if>
         <!-- volgende behandelaar -->
         <!-- MP-1935 add support for zorgaanbieder only -->
         <xsl:for-each select="volgende_behandelaar/(zorgverlener | zorgaanbieder)[@value]">
            <participant>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9446_20221128115041">
                  <xsl:with-param name="in"
                                  select="local:bouwstenen(current())/(zorgverlener | zorgaanbieder)[@id = current()/@value]"/>
               </xsl:call-template>
            </participant>
         </xsl:for-each>
         <!-- Overige onderdelen van deze MA -->
         <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9428_20221122124407">
            <xsl:with-param name="in"
                            select="."/>
         </xsl:call-template>
         <!-- Kopie-indicator -->
         <xsl:if test="kopie_indicator">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9200_20180112101847">
                  <xsl:with-param name="kopie-ind"
                                  select="kopie_indicator"/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:if>
         <!--Relatie naar medicamenteuze behandeling-->
         <entryRelationship typeCode="COMP"
                            inversionInd="true">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
               <xsl:with-param name="MBHroot"
                               select=".."/>
            </xsl:call-template>
         </entryRelationship>
         <!-- relaties huisartsenzorg -->
         <xsl:for-each select="relatie_contact/identificatienummer[@value | @nullFlavor]">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.32_20171221123947"/>
         </xsl:for-each>
         <xsl:for-each select="relatie_zorgepisode/identificatienummer[@value | @nullFlavor]">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.33_20171221124050"/>
         </xsl:for-each>
         <!-- gebruiksperiode/criterium -->
         <xsl:for-each select="gebruiksperiode/criterium[@value]">
            <precondition>
               <criterion>
                  <text mediaType="plain/text">
                     <xsl:value-of select="@value"/>
                  </text>
               </criterion>
            </precondition>
         </xsl:for-each>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9430_20221122132432"
                 match="medicatieafspraak | medication_agreement"
                 mode="ada_2_hl7">
      <!-- Mapping of medicatieafspraak concept in ADA ('eigen of ongedefinieerde MA') to HL7 CDA template 2.16.840.1.113883.2.4.3.11.60.20.77.10.9430 -->
      <xsl:param name="in"
                 select=".">
         <!-- ADA Node to consider in the creation of the hl7 element -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9430"/>
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9429_20221122130054">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9431_20221122133531">
      <!-- Mapping of zib nl.zorg.Medicatieafspraak concept in ADA ('andermans MA') to HL7 CDA template 2.16.840.1.113883.2.4.3.11.60.20.77.10.9429 -->
      <xsl:param name="in"
                 select=".">
         <!-- ADA Node to consider in the creation of the hl7 element -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9431"/>
            <!-- inhoud medicatieafspraak -->
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9429_20221122130054">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9434_20221122135830"
                 match="medicatieafspraak | medication_agreement"
                 mode="HandleMAProposal91">
      <!-- Voorstel Medicatieafspraak -->
      <xsl:param name="in"
                 select=".">
         <!-- The proposed medication agreement -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="PRP">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9434"/>
            <!-- Geen id bij voorstel MA: dit is een vluchtig ding waar toch niet naar verwezen mag worden. -->
            <code code="33633005"
                  displayName="voorschrijven van geneesmiddel (verrichting)"
                  codeSystem="{$oidSNOMEDCT}"
                  codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
            <!-- gebruiksinstructie/omschrijving -->
            <xsl:call-template name="makeInstructionText"/>
            <!-- Gebruiksperiode -->
            <xsl:call-template name="_handleGebruiksperiode"/>
            <xsl:for-each select="gebruiksinstructie/toedieningsweg[.//(@value | @code)]">
               <routeCode>
                  <xsl:call-template name="makeCodeAttribs"/>
               </routeCode>
            </xsl:for-each>
            <!-- backward compatible -->
            <xsl:for-each select="(afgesproken_geneesmiddel/product[not(@value)][.//(@value | @code)] | local:bouwstenen(current())/farmaceutisch_product[@id = current()/afgesproken_geneesmiddel/farmaceutisch_product/@value])[1]">
               <consumable>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9363_20210602155855">
                     <xsl:with-param name="product"
                                     select="."/>
                  </xsl:call-template>
               </consumable>
            </xsl:for-each>
            <!-- Als auteur is er ofwel een zorgverlener, ofwel een zorgaanbieder -->
            <xsl:variable name="currentMA"
                          select="."
                          as="element()"/>
            <xsl:variable name="currentMBH"
                          select="parent::medicamenteuze_behandeling"
                          as="element()?"/>
            <xsl:for-each select="ancestor::adaxml/data/*/(voorstelgegevens | voorstel_gegevens)/voorstel[                     medicatieafspraak/@value = $currentMA/@id                     or                     medicamenteuze_behandeling/@value = $currentMBH/@id                     ][                     auteur[.//(@value | @code | @nullFlavor)]                     or                     (voorsteldatum | voorstel_datum)[@value]                     ]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9387_20210701000000">
                  <xsl:with-param name="adaAuteur"
                                  select="auteur[1]"/>
                  <xsl:with-param name="authorTime"
                                  select="(voorsteldatum | voorstel_datum)[@value][1]"/>
               </xsl:call-template>
            </xsl:for-each>
            <!-- Overige onderdelen van deze MA -->
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9428_20221122124407">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
            <!--Relatie naar medicamenteuze behandeling-->
            <xsl:if test="medicamenteuze_behandeling_id[@value | @root] or ../identificatie[@value | @root]">
               <entryRelationship typeCode="COMP"
                                  inversionInd="true">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
                     <xsl:with-param name="MBHroot"
                                     select=".."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:if>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9438_20221124113046"
                 match="reden_wijzigen_of_staken"
                 mode="HandleRedenAfspraak91">
      <!--  Reden voor medicatieafspraak vanaf 9 2.0 -->
      <observation classCode="OBS"
                   moodCode="EVN">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9438"/>
         <code code="160111000146106"
               displayName="reden voor wijzigen van voorschrift"
               codeSystem="{$oidSNOMEDCT}"
               codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
         <xsl:call-template name="makeCEValue"/>
      </observation>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9439_20221124114130"
                 match="reden_wijzigen_of_staken"
                 mode="HandleRedenWijzStakenWDS">
      <!--  Reden voor wisselenddoseerschema vanaf 9 2.0 -->
      <observation classCode="OBS"
                   moodCode="EVN">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9439"/>
         <code code="160111000146106"
               displayName="reden voor wijzigen van voorschrift"
               codeSystem="{$oidSNOMEDCT}"
               codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
         <xsl:call-template name="makeCEValue"/>
      </observation>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9440_20221124114649">
      <!-- Reden voor wijzigen of staken toedieningsafspraak vanaf 9.2def -->
      <observation classCode="OBS"
                   moodCode="EVN">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9440"/>
         <code code="160121000146101"
               displayName="reden voor wijzigen van toedieningsinstructies"
               codeSystem="{$oidSNOMEDCT}"
               codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
         <xsl:call-template name="makeCEValue">
            <xsl:with-param name="elemName">value</xsl:with-param>
         </xsl:call-template>
      </observation>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9441_20221124125142">
      <!-- Reden voor wijzigen/stoppen medicatiegebruik vanaf MP9 2.0.0 -->
      <observation classCode="OBS"
                   moodCode="EVN">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9441"/>
         <code code="153861000146102"
               displayName="reden voor wijzigen van medicatiegebruik (waarneembare entiteit)"
               codeSystem="2.16.840.1.113883.6.96"
               codeSystemName="SNOMED CT"/>
         <value>
            <xsl:attribute name="xsi:type"
                           select="'CE'"/>
            <xsl:call-template name="makeCodeAttribs"/>
         </value>
      </observation>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9442_20221124134142"
                 match="medicatie_gebruik"
                 mode="HandleMGBContents920">
      <!--  Medicatiegebruik inhoud - vanaf MP 9 2.0 -->
      <xsl:param name="in"
                 select=".">
         <!-- ada element voor medicatiegebruik -->
      </xsl:param>
      <xsl:for-each select="$in">
         <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9442"/>
         <xsl:variable name="isInGebruik"
                       select="gebruik_indicator/@value"
                       as="xs:boolean"/>
         <!-- identificatie -->
         <xsl:for-each select="identificatie[.//(@value | @code)]">
            <xsl:call-template name="makeIIid"/>
         </xsl:for-each>
         <code code="422979000"
               displayName="bevinding betreffende gedrag met betrekking tot medicatieregime (bevinding)"
               codeSystem="{$oidSNOMEDCT}"
               codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
         <!-- gebruiksinstructie/omschrijving -->
         <xsl:call-template name="makeInstructionText"/>
         <!-- Gebruiksperiode -->
         <xsl:call-template name="_handleGebruiksperiode"/>
         <!-- routeCode -->
         <xsl:for-each select="gebruiksinstructie/toedieningsweg[.//(@value | @code)]">
            <xsl:call-template name="makeCDValue">
               <xsl:with-param name="elemName">routeCode</xsl:with-param>
               <xsl:with-param name="xsiType"
                               select="''"/>
            </xsl:call-template>
         </xsl:for-each>
         <!-- consumable, is 1..1 in xsd, so always has to be outputted -->
         <consumable>
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9363_20210602155855">
               <xsl:with-param name="product"
                               select="(local:bouwstenen(current())/farmaceutisch_product[@id = current()/gebruiksproduct/farmaceutisch_product/@value])[1]"/>
            </xsl:call-template>
         </consumable>
         <!-- author and time -->
         <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9387_20210701000000">
            <xsl:with-param name="adaAuteur"
                            select="./auteur[.//(@value | @code)]"/>
            <xsl:with-param name="authorTime"
                            select="(registratiedatum | registratie_datum_tijd | medicatiegebruik_datum_tijd)"/>
         </xsl:call-template>
         <!-- Informant van het medicatiegebruik: zorgverlener -->
         <xsl:for-each select="local:bouwstenen(current())/zorgverlener[@id = current()/informant/informant_is_zorgverlener/zorgverlener/@value]">
            <informant>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.34_20210701000000"/>
            </informant>
         </xsl:for-each>
         <!-- Informant van het medicatiegebruik: patiënt -->
         <xsl:if test="informant/informant_is_patient/@value = 'true'">
            <informant>
               <assignedEntity>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.52_20170825000000"/>
               </assignedEntity>
            </informant>
         </xsl:if>
         <!-- Informant van het medicatiegebruik: contactpartij = ander persoon -->
         <xsl:for-each select="local:bouwstenen(current())/contactpersoon[@id = current()/informant/persoon/contactpersoon/@value]">
            <informant>
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.30_20210701000000"/>
            </informant>
         </xsl:for-each>
         <!-- Gebruik indicator -->
         <xsl:for-each select="gebruik_indicator[.//(@value | @nullFlavor)]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9189_20171026161543"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Volgens afspraak indicator -->
         <xsl:for-each select="volgens_afspraak_indicator[.//(@value | @nullFlavor)]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9317_20200120141110"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Stoptype -->
         <xsl:for-each select="(medicatiegebruik_stop_type | medicatie_gebruik_stop_type | stoptype)[.//(@value | @code)]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9414_20221118141506"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Aanvullende Instructie. -->
         <xsl:for-each select="gebruiksinstructie/aanvullende_instructie[.//(@value | @code)]">
            <entryRelationship typeCode="SPRT">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9085_20160621114818">
                  <xsl:with-param name="ada-aanvullende-instructie"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- Reden gebruik -->
         <xsl:for-each select="reden_gebruik[@value | @nullFlavor]">
            <entryRelationship typeCode="RSON">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9390_20210816074229"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Reden wijzigen/stoppen gebruik -->
         <xsl:for-each select="reden_wijzigen_of_stoppen_gebruik[.//(@value | @code)]">
            <entryRelationship typeCode="RSON">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9441_20221124125142"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Toelichting -->
         <xsl:for-each select="toelichting[@value | @nullFlavor]">
            <entryRelationship typeCode="SUBJ"
                               inversionInd="true">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
            </entryRelationship>
         </xsl:for-each>
         <!--Doseerinstructie-->
         <xsl:for-each select="gebruiksinstructie/doseerinstructie[.//(@value | @code | @nullFlavor)]">
            <xsl:call-template name="_handleDoseerinstructie"/>
         </xsl:for-each>
         <!-- Relatie naar (voorschrift met) voorschrijver -->
         <xsl:for-each select="local:bouwstenen(current())/zorgverlener[@id = current()/voorschrijver/zorgverlener/@value]">
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9388_20210709160923"/>
            </entryRelationship>
         </xsl:for-each>
         <!-- Kopie-indicator -->
         <xsl:if test="kopie_indicator[@value | @code | @nullFlavor]">
            <entryRelationship typeCode="COMP">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9200_20180112101847">
                  <xsl:with-param name="kopie-ind"
                                  select="kopie_indicator"/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:if>
         <!-- Relatie naar afspraak (medicatieafspraak óf toedieningsafspraak) -->
         <!-- Eigenlijk zit hier template 2.16.840.1.113883.2.4.3.11.60.77.10.9120 (MP Afspraak Identificatie) omheen,
              maar omdat die geen eigen elementen bevat, maar alleen een keuze, is die niet uitgewerkt. 
              Hier doen we geen input validatie, dus wordt elk aanwezig element omgezet. -->
         <xsl:for-each select="(gerelateerde_afspraak/identificatie_medicatieafspraak | relatie_medicatieafspraak/identificatie)[.//(@value | @code)]">
            <!-- kunnen er 0 of 1 zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                  <xsl:with-param name="identificatieElement"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <xsl:for-each select="(gerelateerde_afspraak/identificatie_toedieningsafspraak | relatie_toedieningsafspraak/identificatie)[.//(@value | @code)]">
            <!-- kunnen er 0 of 1 zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9101_20160624130316">
                  <xsl:with-param name="identificatieElement"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- Relatie naar verstrekking -->
         <xsl:for-each select="(gerelateerde_verstrekking | relatie_medicatieverstrekking)/identificatie[.//(@value | @code)]">
            <!-- kunnen er 0 of 1 zijn -->
            <entryRelationship typeCode="REFR">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9102_20160624133045">
                  <xsl:with-param name="identificatieElement"
                                  select="."/>
               </xsl:call-template>
            </entryRelationship>
         </xsl:for-each>
         <!-- Relatie naar medicamenteuze behandeling -->
         <entryRelationship typeCode="COMP"
                            inversionInd="true">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
               <xsl:with-param name="MBHroot"
                               select=".."/>
            </xsl:call-template>
         </entryRelationship>
         <!-- relaties huisartsenzorg -->
         <xsl:for-each select="relatie_contact/identificatienummer[@value | @nullFlavor]">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.32_20171221123947"/>
         </xsl:for-each>
         <xsl:for-each select="relatie_zorgepisode/identificatienummer[@value | @nullFlavor]">
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.33_20171221124050"/>
         </xsl:for-each>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9443_20221124135001"
                 match="medicatie_gebruik | medicatiegebruik"
                 mode="HandleMGBKopie920">
      <!-- Medicatiegebruik - vanaf MP 9 2.0 - Kopie  -->
      <xsl:param name="in"
                 select=".">
         <!-- ada element voor medicatiegebruik -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="EVN"
                                  negationInd="false">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9443"/>
            <!-- inhoud medicatiegebruik -->
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9442_20221124134142">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9444_20221124154710"
                 match="medicatie_gebruik | medicatiegebruik"
                 mode="HandleMGB920">
      <!-- Medicatiegebruik - vanaf MP 9 2.0  -->
      <xsl:param name="in"
                 select=".">
         <!-- ada element voor medicatiegebruik -->
      </xsl:param>
      <xsl:for-each select="$in">
         <substanceAdministration classCode="SBADM"
                                  moodCode="EVN"
                                  negationInd="false">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9444"/>
            <!-- inhoud medicatiegebruik -->
            <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9442_20221124134142">
               <xsl:with-param name="in"
                               select="."/>
            </xsl:call-template>
         </substanceAdministration>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9446_20221128115041">
      <!-- MA volgende behandelaar zorgverlener or (from MP-1935 onwards) zorgaanbieder -->
      <xsl:param name="in"
                 select=".">
         <!-- ada element to be handled -->
      </xsl:param>
      <xsl:for-each select="$in">
         <xsl:attribute name="typeCode">CALLBCK</xsl:attribute>
         <xsl:attribute name="contextControlCode">OP</xsl:attribute>
         <participantRole classCode="ROL">
            <xsl:if test="self::zorgverlener">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.37_20210701000000">
                  <xsl:with-param name="hl7PersonElementname"
                                  select="'playingEntity'"/>
                  <xsl:with-param name="hl7OrgElementname"
                                  select="'scopingEntity'"/>
                  <xsl:with-param name="hl7OrgNameElementname"
                                  select="'desc'"/>
               </xsl:call-template>
            </xsl:if>
            <!-- assumption for reference use is that zorgverlener and zorgaanbieder are both in same 'bouwstenen' folder in dataset -->
            <xsl:for-each select="self::zorgaanbieder">
               <scopingEntity>
                  <xsl:for-each select="(zorgaanbieder_identificatie_nummer | zorgaanbieder_identificatienummer)">
                     <!-- MP CDA Zorgaanbieder identificaties -->
                     <xsl:call-template name="makeIIid"/>
                  </xsl:for-each>
                  <xsl:for-each select="organisatie_type">
                     <code>
                        <xsl:call-template name="makeCodeAttribs"/>
                     </code>
                  </xsl:for-each>
                  <xsl:for-each select="organisatie_naam[@value | @nullFlavor]">
                     <desc>
                        <xsl:choose>
                           <xsl:when test="string-length(@value) gt 0">
                              <xsl:value-of select="@value"/>
                           </xsl:when>
                           <xsl:when test="@nullFlavor">
                              <xsl:attribute name="nullFlavor">
                                 <xsl:value-of select="@nullFlavor"/>
                              </xsl:attribute>
                           </xsl:when>
                           <xsl:otherwise>
                              <xsl:attribute name="nullFlavor">NI</xsl:attribute>
                           </xsl:otherwise>
                        </xsl:choose>
                     </desc>
                  </xsl:for-each>
               </scopingEntity>
            </xsl:for-each>
         </participantRole>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9448_20230106092258">
      <!-- Aanvullende wens -->
      <xsl:param name="in"
                 select=".">
         <!-- Optional. Input element, defaults to context. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <act classCode="ACT"
              moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9448"/>
            <xsl:call-template name="makeCode">
               <xsl:with-param name="elemName">code</xsl:with-param>
            </xsl:call-template>
         </act>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9449_20230106093041"
                 match="verstrekkingsverzoek"
                 mode="HandleVV92">
      <!--  Verstrekkingsverzoek vanaf 9 2.0 -->
      <xsl:param name="in"
                 select="."
                 as="element()*">
         <!-- ada verstrekkingsverzoek to be converted, defaults to context -->
      </xsl:param>
      <xsl:for-each select="$in[.//(@value | @code)]">
         <supply classCode="SPLY"
                 moodCode="RQO">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9449"/>
            <!-- identificatie -->
            <xsl:for-each select="identificatie[@value]">
               <xsl:call-template name="makeIIid"/>
            </xsl:for-each>
            <code code="52711000146108"
                  displayName="Verstrekkingsverzoek"
                  codeSystem="{$oidSNOMEDCT}"
                  codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
            <!-- statusCode: voor foutcorrectie -->
            <xsl:if test="geannuleerd_indicator/@value = 'true'">
               <statusCode code="nullified"/>
            </xsl:if>
            <!-- aantal herhalingen -->
            <xsl:for-each select="aantal_herhalingen[@value]">
               <repeatNumber>
                  <xsl:attribute name="value"
                                 select="xs:integer(./@value) + 1"/>
               </repeatNumber>
            </xsl:for-each>
            <!-- Te verstrekken hoeveelheid -->
            <xsl:for-each select="te_verstrekken_hoeveelheid[.//@value]">
               <quantity>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9165_20170118000000"/>
               </quantity>
            </xsl:for-each>
            <!-- verbruiksperiode -->
            <xsl:for-each select="verbruiksperiode[.//(@value | @code)]">
               <expectedUseTime>
                  <xsl:for-each select="ingangsdatum | start_datum_tijd">
                     <low>
                        <xsl:call-template name="makeTSValueAttr"/>
                     </low>
                  </xsl:for-each>
                  <xsl:for-each select="duur | tijds_duur">
                     <width>
                        <xsl:call-template name="makeTimePQValueAttribs"/>
                     </width>
                  </xsl:for-each>
                  <xsl:for-each select="einddatum | eind_datum_tijd">
                     <high>
                        <xsl:call-template name="makeTSValueAttr"/>
                     </high>
                  </xsl:for-each>
               </expectedUseTime>
            </xsl:for-each>
            <!-- Te verstrekken geneesmiddel -->
            <xsl:for-each select="(local:bouwstenen(current())/farmaceutisch_product[@id = current()/te_verstrekken_geneesmiddel/farmaceutisch_product/@value])[1]">
               <product>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9362_20210602154632">
                     <xsl:with-param name="product"
                                     select="."/>
                  </xsl:call-template>
               </product>
            </xsl:for-each>
            <!-- beoogd verstrekker -->
            <xsl:for-each select="local:bouwstenen(current())/zorgaanbieder[@id = current()/beoogd_verstrekker/zorgaanbieder/@value]">
               <performer>
                  <assignedEntity>
                     <id nullFlavor="NI"/>
                     <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.33_20210701000000"/>
                  </assignedEntity>
               </performer>
            </xsl:for-each>
            <!-- Auteur / zorgverlener -->
            <xsl:variable name="vvAfspraakDatumTijd"
                          select="verstrekkingsverzoek_datum | datum | verstrekkingsverzoek_datum_tijd"
                          as="element()*"/>
            <xsl:variable name="vvAuthor"
                          select="local:bouwstenen(current())/zorgverlener[@id = current()/auteur/zorgverlener/@value]"
                          as="element()*"/>
            <xsl:if test="$vvAuthor | $vvAfspraakDatumTijd">
               <author>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.121.10.32_20210701000000">
                     <xsl:with-param name="in"
                                     select="$vvAuthor[1]"/>
                     <xsl:with-param name="theTime"
                                     select="$vvAfspraakDatumTijd[1]"/>
                  </xsl:call-template>
               </author>
            </xsl:if>
            <!-- afleverlocatie -->
            <xsl:for-each select="afleverlocatie[.//(@value | @code)]">
               <participant typeCode="DST">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9091_20160621153127"/>
               </participant>
            </xsl:for-each>
            <!-- aanvullende wensen -->
            <xsl:for-each select="aanvullende_wensen[@value | @code | @nullFlavor | @originalText]">
               <!-- kunnen er 0 of meer zijn -->
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9448_20230106092258"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- financiële indicatiecode -->
            <xsl:for-each select="financiele_indicatiecode[@code]">
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9357_2021002133425"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- Toelichting -->
            <xsl:for-each select="toelichting[@value]">
               <entryRelationship typeCode="SUBJ"
                                  inversionInd="true">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- relatie naar MA -->
            <xsl:for-each select="(relatie_naar_medicatieafspraak | relatie_medicatieafspraak)[identificatie[@value | @nullFlavor]]">
               <!-- kunnen er 0 of meer zijn -->
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                     <xsl:with-param name="identificatieElement"
                                     select="identificatie"/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!--Relatie naar medicamenteuze behandeling - wordt automatisch gegenereerd -->
            <entryRelationship typeCode="COMP"
                               inversionInd="true">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
                  <xsl:with-param name="MBHroot"
                                  select="./.."/>
               </xsl:call-template>
            </entryRelationship>
            <!-- relaties huisartsenzorg -->
            <xsl:for-each select="relatie_contact/identificatienummer[@value | @nullFlavor]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.32_20171221123947"/>
            </xsl:for-each>
            <xsl:for-each select="relatie_zorgepisode/identificatienummer[@value | @nullFlavor]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.7.10.33_20171221124050"/>
            </xsl:for-each>
         </supply>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9451_20230106095110">
      <!-- Voorstel Verstrekkingsverzoek -->
      <xsl:param name="in"
                 as="element()?"
                 select=".">
         <!-- The input ada verstrekkingsverzoek, defaults to context -->
      </xsl:param>
      <!--MP CDA Voorstel Verstrekkingsverzoek-->
      <xsl:for-each select="$in">
         <supply classCode="SPLY"
                 moodCode="PRP">
            <templateId root="2.16.840.1.113883.2.4.3.11.60.20.77.10.9451"/>
            <code code="52711000146108"
                  displayName="Verstrekkingsverzoek"
                  codeSystem="{$oidSNOMEDCT}"
                  codeSystemName="{$oidMap[@oid=$oidSNOMEDCT]/@displayName}"/>
            <!-- aantal herhalingen -->
            <xsl:for-each select="aantal_herhalingen[@value]">
               <repeatNumber>
                  <xsl:attribute name="value"
                                 select="xs:integer(./@value) + 1"/>
               </repeatNumber>
            </xsl:for-each>
            <!-- Te verstrekken hoeveelheid -->
            <xsl:for-each select="te_verstrekken_hoeveelheid[.//(@value | @code)]">
               <quantity>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9165_20170118000000"/>
               </quantity>
            </xsl:for-each>
            <!-- verbruiksperiode -->
            <xsl:for-each select="verbruiksperiode[.//(@value | @code)]">
               <expectedUseTime>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9019_20160701155001">
                     <xsl:with-param name="low"
                                     select="ingangsdatum"/>
                     <xsl:with-param name="width"
                                     select="./duur"/>
                     <xsl:with-param name="high"
                                     select="./einddatum"/>
                  </xsl:call-template>
               </expectedUseTime>
            </xsl:for-each>
            <!-- Te verstrekken geneesmiddel -->
            <xsl:for-each select="(te_verstrekken_geneesmiddel/product[not(@value)][.//(@value | @code)] | local:bouwstenen(current())/farmaceutisch_product[@id = current()/te_verstrekken_geneesmiddel/farmaceutisch_product/@value])[1]">
               <product>
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9363_20210602155855">
                     <xsl:with-param name="product"
                                     select="."/>
                  </xsl:call-template>
               </product>
            </xsl:for-each>
            <!-- beoogd verstrekker -->
            <xsl:for-each select="beoogd_verstrekker/zorgaanbieder[not(@value)][.//(@value | @code)] | local:bouwstenen(current())/zorgaanbieder[@id = current()/beoogd_verstrekker/zorgaanbieder/@value]">
               <performer>
                  <assignedEntity>
                     <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9088_20160621133312"/>
                  </assignedEntity>
               </performer>
            </xsl:for-each>
            <!-- Auteur voorstelgegevens, gekoppeld aan oude en nieuwe MBH-modellering -->
            <xsl:variable name="currentVV"
                          select="."
                          as="element()"/>
            <xsl:variable name="currentMBH"
                          select="parent::medicamenteuze_behandeling"
                          as="element()?"/>
            <xsl:for-each select="ancestor::adaxml/data/*/(voorstelgegevens | voorstel_gegevens)/voorstel[                     verstrekkingsverzoek/@value = $currentVV/@id                     or                     medicamenteuze_behandeling/@value = $currentMBH/@id                     ][                     auteur[.//(@value | @code | @nullFlavor)]                     or                     (voorsteldatum | voorstel_datum)[@value]                     ]">
               <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9387_20210701000000">
                  <xsl:with-param name="adaAuteur"
                                  select="auteur[1]"/>
                  <xsl:with-param name="authorTime"
                                  select="(voorsteldatum | voorstel_datum)[@value][1]"/>
               </xsl:call-template>
            </xsl:for-each>
            <!-- afleverlocatie -->
            <xsl:for-each select="afleverlocatie[.//(@value | @code | @nullFlavor)]">
               <participant typeCode="DST">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9091_20160621153127"/>
               </participant>
            </xsl:for-each>
            <!-- aanvullende wensen -->
            <xsl:for-each select="aanvullende_wensen[.//(@value | @code | @nullFlavor)]">
               <!-- kunnen er 0 of meer zijn -->
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9093_20160623183534"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- financiële indicatiecode -->
            <xsl:for-each select="financiele_indicatiecode[@code]">
               <entryRelationship typeCode="COMP">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9357_2021002133425"/>
               </entryRelationship>
            </xsl:for-each>
            <!-- Toelichting op het VV -->
            <xsl:for-each select="toelichting[.//(@value | @code | @nullFlavor)]">
               <entryRelationship typeCode="SUBJ"
                                  inversionInd="true">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.0.32_20180611000000"/>
               </entryRelationship>
            </xsl:for-each>
            <!--Relatie naar medicatieafspraak -->
            <xsl:for-each select="(relatie_naar_medicatieafspraak | relatie_medicatieafspraak)[.//(@value | @code | @nullFlavor)]">
               <entryRelationship typeCode="REFR">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9384_20210618">
                     <xsl:with-param name="identificatieElement"
                                     select="identificatie"/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:for-each>
            <!-- Relatie naar medicamenteuze behandeling -->
            <xsl:if test="medicamenteuze_behandeling_id[@value | @root] or ../identificatie[@value | @root]">
               <entryRelationship typeCode="COMP"
                                  inversionInd="true">
                  <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9084_20160621103838">
                     <xsl:with-param name="MBHroot"
                                     select=".."/>
                  </xsl:call-template>
               </entryRelationship>
            </xsl:if>
         </supply>
      </xsl:for-each>
   </xsl:template>
</xsl:stylesheet>