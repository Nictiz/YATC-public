<?xml version="1.0" encoding="UTF-8"?>

<!-- == Provenance: YATC-internal/ada-2-fhir-r4/env/zibs/2020/payload/0.11.0-beta.1/nl-core-AbilityToUseToilet.xsl == -->
<!-- == Distribution: MP9-Medicatieproces-9.3.0; 1.0.18; 2026-08-20T14:36:33.25+02:00 == -->
<xsl:stylesheet exclude-result-prefixes="#all"
                version="2.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns="http://hl7.org/fhir"
                xmlns:util="urn:hl7:utilities"
                xmlns:f="http://hl7.org/fhir"
                xmlns:nf="http://www.nictiz.nl/functions"
                xmlns:yatcs="https://nictiz.nl/ns/YATC-shared"
                xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
                xmlns:uuid="http://www.uuid.org"
                xmlns:local="#local.2024111408212923221350100">
   <!-- ================================================================== -->
   <!--
        Converts ADA vermogen_tot_toiletgang to FHIR Observation resource conforming to profile nl-core-AbilityToUseToilet.
    -->
   <!-- ================================================================== -->
   <!--
        Copyright © Nictiz
        
        This program is free software; you can redistribute it and/or modify it under the terms of the
        GNU Lesser General Public License as published by the Free Software Foundation; either version
        2.1 of the License, or (at your option) any later version.
        
        This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
        without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU Lesser General Public License for more details.
        
        The full text of the license is available at http://www.gnu.org/copyleft/lesser.html
    -->
   <!-- ================================================================== -->
   <xsl:output method="xml"
               indent="yes"/>
   <xsl:strip-space elements="*"/>
   <xsl:variable name="profileNameAbilityToUseToilet"
                 select="'nl-core-AbilityToUseToilet'"/>
   <xsl:variable name="profileNameAbilityToUseToiletToiletUse"
                 select="'nl-core-AbilityToUseToilet.ToiletUse'"/>
   <xsl:variable name="profileNameAbilityToUseToiletMenstrualCare"
                 select="'nl-core-AbilityToUseToilet.MenstrualCare'"/>
   <!-- ================================================================== -->
   <xsl:template match="vermogen_tot_toiletgang"
                 name="nl-core-AbilityToUseToilet"
                 mode="nl-core-AbilityToUseToilet"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-AbilityToUseToilet instance as an Observation FHIR instance from ADA vermogen_tot_toiletgang element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?">
         <!-- Optional ADA instance or ADA reference element for the patient. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameAbilityToUseToilet"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="284779002"/>
                  <display value="vermogen om activiteit voor persoonlijke hygiëne uit te voeren"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <xsl:for-each select="toiletgebruik">
               <hasMember>
                  <xsl:call-template name="makeReference">
                     <xsl:with-param name="in"
                                     select="."/>
                     <xsl:with-param name="profile"
                                     select="$profileNameAbilityToUseToiletToiletUse"/>
                  </xsl:call-template>
               </hasMember>
            </xsl:for-each>
            <xsl:for-each select="zorg_bij_menstruatie">
               <hasMember>
                  <xsl:call-template name="makeReference">
                     <xsl:with-param name="in"
                                     select="."/>
                     <xsl:with-param name="profile"
                                     select="$profileNameAbilityToUseToiletMenstrualCare"/>
                  </xsl:call-template>
               </hasMember>
            </xsl:for-each>
         </Observation>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="toiletgebruik[parent::vermogen_tot_toiletgang]"
                 name="nl-core-AbilityToUseToilet.ToiletUse"
                 mode="nl-core-AbilityToUseToilet.ToiletUse"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-AbilityToUseToilet.ToiletUse instance as an Observation FHIR instance from ADA toiletgebruik element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?">
         <!-- Optional ADA instance or ADA reference element for the patient. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameAbilityToUseToiletToiletUse"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="284899001"/>
                  <display value="vermogen om activiteit voor toiletgang uit te voeren"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <valueCodeableConcept>
               <xsl:call-template name="code-to-CodeableConcept">
                  <xsl:with-param name="in"
                                  select="."/>
               </xsl:call-template>
            </valueCodeableConcept>
         </Observation>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="zorg_bij_menstruatie[parent::vermogen_tot_toiletgang]"
                 name="nl-core-AbilityToUseToilet.MenstrualCare"
                 mode="nl-core-AbilityToUseToilet.MenstrualCare"
                 as="element(f:Observation)?">
      <!-- Creates an nl-core-AbilityToUseToilet.MenstrualCare instance as an Observation FHIR instance from ADA zorg_bij_menstruatie element. -->
      <xsl:param name="in"
                 select="."
                 as="element()?">
         <!-- ADA element as input. Defaults to self. -->
      </xsl:param>
      <xsl:param name="subject"
                 select="patient/*"
                 as="element()?">
         <!-- Optional ADA instance or ADA reference element for the patient. -->
      </xsl:param>
      <xsl:for-each select="$in">
         <Observation>
            <xsl:call-template name="insertLogicalId">
               <xsl:with-param name="profile"
                               select="$profileNameAbilityToUseToiletMenstrualCare"/>
            </xsl:call-template>
            <meta>
               <profile value="{nf:get-full-profilename-from-adaelement(.)}"/>
            </meta>
            <status value="final"/>
            <code>
               <coding>
                  <system value="{$oidMap[@oid=$oidSNOMEDCT]/@uri}"/>
                  <code value="284955009"/>
                  <display value="vermogen om activiteit voor menstruatiehygiëne uit te voeren"/>
               </coding>
            </code>
            <xsl:call-template name="makeReference">
               <xsl:with-param name="in"
                               select="$subject"/>
               <xsl:with-param name="wrapIn"
                               select="'subject'"/>
            </xsl:call-template>
            <valueCodeableConcept>
               <xsl:call-template name="code-to-CodeableConcept">
                  <xsl:with-param name="in"
                                  select="."/>
               </xsl:call-template>
            </valueCodeableConcept>
         </Observation>
      </xsl:for-each>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="vermogen_tot_toiletgang"
                 mode="_generateDisplay">
      <!-- Template to generate a display that can be shown when referencing this instance. -->
      <xsl:variable name="parts"
                    as="item()*">
         <xsl:text>Vermogen tot toiletgang observatie</xsl:text>
      </xsl:variable>
      <xsl:value-of select="string-join($parts[. != ''], ', ')"/>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="toiletgebruik[parent::vermogen_tot_toiletgang]"
                 mode="_generateDisplay">
      <xsl:variable name="parts"
                    as="item()*">
         <xsl:text>Toiletgebruik</xsl:text>
         <xsl:if test=".[@value]">
            <xsl:value-of select="./@displayName"/>
         </xsl:if>
      </xsl:variable>
      <xsl:value-of select="string-join($parts, ': ')"/>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template match="zorg_bij_menstruatie[parent::vermogen_tot_toiletgang]"
                 mode="_generateDisplay">
      <xsl:variable name="parts"
                    as="item()*">
         <xsl:text>Zorg bij menstruatie</xsl:text>
         <xsl:if test=".[@value]">
            <xsl:value-of select="./@displayName"/>
         </xsl:if>
      </xsl:variable>
      <xsl:value-of select="string-join($parts, ': ')"/>
   </xsl:template>
</xsl:stylesheet>