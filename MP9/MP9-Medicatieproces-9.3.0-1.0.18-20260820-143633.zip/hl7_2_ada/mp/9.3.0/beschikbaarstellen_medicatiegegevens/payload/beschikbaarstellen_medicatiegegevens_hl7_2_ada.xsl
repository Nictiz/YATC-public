<?xml version="1.0" encoding="UTF-8"?>

<!-- == Provenance: YATC-internal/hl7-2-ada/env/mp/9.3.0/beschikbaarstellen_medicatiegegevens/payload/beschikbaarstellen_medicatiegegevens_hl7_2_ada.xsl == -->
<!-- == Distribution: MP9-Medicatieproces-9.3.0; 1.0.18; 2026-08-20T14:36:33.25+02:00 == -->
<xsl:stylesheet exclude-result-prefixes="#all"
                version="2.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:hl7="urn:hl7-org:v3"
                xmlns:sdtc="urn:hl7-org:sdtc"
                xmlns:f="http://hl7.org/fhir"
                xmlns:nf="http://www.nictiz.nl/functions"
                xmlns:hl7nl="urn:hl7-nl:v3"
                xmlns:yatcs="https://nictiz.nl/ns/YATC-shared"
                xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
                xmlns:local="#local.2024120415184394357190100"
                xmlns:pharm="urn:ihe:pharm:medication"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   <!-- ================================================================== -->
   <!--
        TBD
    -->
   <!-- ================================================================== -->
   <!--
        Copyright © Nictiz
        
        This program is free software; you can redistribute it and/or modify it under the terms of the
        GNU Lesser General Public License as published by the Free Software Foundation; either version
        2.1 of the License, or (at your option) any later version.
        
        This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
        without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
        See the GNU Lesser General Public License for more details.
        
        The full text of the license is available at http://www.gnu.org/copyleft/lesser.html
    -->
   <!-- ================================================================== -->
   <xsl:import href="../../../../../common/includes/all-zibs.xsl"/>
   <xsl:import href="../../../../../common/includes/mp-handle-bouwstenen.xsl"/>
   <xsl:output method="xml"
               indent="yes"
               exclude-result-prefixes="#all"
               omit-xml-declaration="yes"/>
   <!-- parameter to control whether or not the result should contain a reference to the ada xsd -->
   <xsl:param name="outputSchemaRef"
              as="xs:boolean"
              select="true()"/>
   <xsl:param name="schemaFileString"
              as="xs:string?">../../hl7_2_ada/mp/9.3.0/beschikbaarstellen_medicatiegegevens/ada_schemas/beschikbaarstellen_medicatiegegevens.xsd</xsl:param>
   <!-- whether or not this hl7_2_ada conversion should deduplicate bouwstenen, such as products, health providers, health professionals, contact persons -->
   <!--    <xsl:param name="deduplicateAdaBouwstenen" as="xs:boolean?" select="false()"/>-->
   <xsl:param name="deduplicateAdaBouwstenen"
              as="xs:boolean?"
              select="true()"/>
   <!-- Schakelparameter voor nieuwe MBHid om backward compatible te houden -->
   <xsl:param name="outputNewMbhModel"
              as="xs:boolean"
              select="true()"/>
   <!-- parameter om creation/lastupdate date stabiel te houden om wijzigingen te beperken in testomgevingen, defaults to current-datetime() -->
   <xsl:param name="creationLastupdate"
              as="xs:dateTime"
              select="current-dateTime()"/>
   <xsl:variable name="medicatiegegevens-lijst-93"
                 select="//hl7:organizer[hl7:code[@code = '102'][@codeSystem = '2.16.840.1.113883.2.4.3.11.60.20.77.4']] | //hl7:organizer[hl7:code[@code = '419891008'][@codeSystem = '2.16.840.1.113883.6.96']] | hl7:ClinicalDocument[hl7:code[@code = '52981000146104'][@codeSystem = '2.16.840.1.113883.6.96']]"/>
   <xsl:variable name="filename"
                 select="tokenize(base-uri(/), '/')[last()]"/>
   <xsl:variable name="extension"
                 select="tokenize($filename, '\.')[last()]"/>
   <xsl:variable name="idBasedOnFilename"
                 select="replace($filename, concat('.', $extension, '$'), '')"/>
   <xsl:param name="theId">
      <xsl:choose>
         <xsl:when test="string-length($idBasedOnFilename) gt 0">
            <xsl:value-of select="$idBasedOnFilename"/>
         </xsl:when>
         <xsl:when test="string-length($medicatiegegevens-lijst-93/../../../hl7:id/@extension) gt 0">
            <!-- let's use the extension of the message id -->
            <xsl:value-of select="$medicatiegegevens-lijst-93/../../../hl7:id/@extension"/>
         </xsl:when>
         <xsl:otherwise>
            <xsl:value-of select="generate-id(.)"/>
         </xsl:otherwise>
      </xsl:choose>
   </xsl:param>
   <!-- ================================================================== -->
   <xsl:template match="/">
      <!--  if this xslt is used stand alone the template below could be used.  -->
      <xsl:call-template name="Medicatiegegevens-93-ADA">
         <xsl:with-param name="medicatiegegevens-lijst"
                         select="$medicatiegegevens-lijst-93"/>
      </xsl:call-template>
   </xsl:template>
   <!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
   <xsl:template name="Medicatiegegevens-93-ADA">
      <!-- Handles HL7 9 3.0 medication information, transforms it to ada. -->
      <xsl:param name="medicatiegegevens-lijst"
                 select="$medicatiegegevens-lijst-93">
         <!-- HL7 9 3.0 organizer/CDA with medication information. -->
      </xsl:param>
      <xsl:call-template name="doGeneratedComment">
         <xsl:with-param name="in"
                         select="$medicatiegegevens-lijst/ancestor::*[hl7:ControlActProcess]"/>
      </xsl:call-template>
      <xsl:variable name="adaXml">
         <adaxml>
            <xsl:if test="$outputSchemaRef">
               <xsl:attribute name="xsi:noNamespaceSchemaLocation">../ada_schemas/ada_beschikbaarstellen_medicatiegegevens.xsd</xsl:attribute>
            </xsl:if>
            <meta status="new"
                  created-by="generated"
                  last-update-by="generated">
               <xsl:attribute name="creation-date"
                              select="$creationLastupdate"/>
               <xsl:attribute name="last-update-date"
                              select="$creationLastupdate"/>
            </meta>
            <data>
               <xsl:for-each select="$medicatiegegevens-lijst">
                  <xsl:call-template name="doGeneratedComment"/>
                  <xsl:variable name="patient"
                                select="hl7:recordTarget/hl7:patientRole"/>
                  <beschikbaarstellen_medicatiegegevens app="mp-mp93"
                                                        shortName="beschikbaarstellen_medicatiegegevens"
                                                        formName="medicatiegegevens"
                                                        transactionRef="2.16.840.1.113883.2.4.3.11.60.20.77.4.374"
                                                        transactionEffectiveDate="2022-06-30T00:00:00"
                                                        prefix="mp-"
                                                        language="nl-NL"
                                                        title="{$theId}"
                                                        id="{$theId}">
                     <xsl:for-each select="$patient">
                        <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.3.10.1_20210701">
                           <xsl:with-param name="in"
                                           select="."/>
                           <xsl:with-param name="language"
                                           select="$language"/>
                        </xsl:call-template>
                     </xsl:for-each>
                     <xsl:variable name="component"
                                   select=".//*[hl7:templateId/@root = ($templateId-medicatieafspraak, $templateId-wisselend_doseerschema, $templateId-verstrekkingsverzoek, $templateId-toedieningsafspraak, $templateId-medicatieverstrekking, $templateId-medicatiegebruik, $templateId-medicatietoediening)]"/>
                     <xsl:for-each-group select="$component"
                                         group-by="hl7:entryRelationship/hl7:procedure[hl7:templateId/@root = $templateId-medicamenteuze-behandeling]/hl7:id/concat(@root, @extension)">
                        <!-- medicamenteuze_behandeling -->
                        <medicamenteuze_behandeling>
                           <xsl:for-each select="./hl7:entryRelationship/hl7:procedure[hl7:templateId/@root = $templateId-medicamenteuze-behandeling]/hl7:id">
                              <xsl:call-template name="handleII">
                                 <xsl:with-param name="elemName">identificatie</xsl:with-param>
                                 <xsl:with-param name="in"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- medicatieafspraak -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-medicatieafspraak]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9430_20221122132432">
                                 <xsl:with-param name="ma_hl7"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- wisselend_doseerschema -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-wisselend_doseerschema]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9412_20221118130922">
                                 <xsl:with-param name="in_hl7"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- verstrekkingsverzoek -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-verstrekkingsverzoek]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9449_20230106093041">
                                 <xsl:with-param name="in"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- toedieningsafspraak -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-toedieningsafspraak]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9416_20221121074758">
                                 <xsl:with-param name="in"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- verstrekking -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-medicatieverstrekking]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9364_20210602161935">
                                 <xsl:with-param name="in"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- medicatiegebruik -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-medicatiegebruik]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9444_20221124154710">
                                 <xsl:with-param name="in"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                           <!-- medicatietoediening -->
                           <xsl:for-each select="current-group()[hl7:templateId/@root = $templateId-medicatietoediening]">
                              <xsl:call-template name="template_2.16.840.1.113883.2.4.3.11.60.20.77.10.9406_20221101091730">
                                 <xsl:with-param name="in"
                                                 select="."/>
                              </xsl:call-template>
                           </xsl:for-each>
                        </medicamenteuze_behandeling>
                     </xsl:for-each-group>
                  </beschikbaarstellen_medicatiegegevens>
               </xsl:for-each>
            </data>
         </adaxml>
      </xsl:variable>
      <xsl:variable name="adaXmlWithBouwstenen">
         <xsl:choose>
            <xsl:when test="$deduplicateAdaBouwstenen = true()">
               <xsl:variable name="adaXmlDeduplicated">
                  <xsl:apply-templates select="$adaXml"
                                       mode="deduplicateBouwstenenStep1"/>
               </xsl:variable>
               <xsl:apply-templates select="$adaXmlDeduplicated"
                                    mode="deduplicateBouwstenenStep2"/>
            </xsl:when>
            <xsl:otherwise>
               <!-- don't deduplicate the bouwstenen -->
               <xsl:apply-templates select="$adaXml"
                                    mode="handleBouwstenen"/>
            </xsl:otherwise>
         </xsl:choose>
      </xsl:variable>
      <!-- Nieuw MBHid backward compatible -->
      <xsl:choose>
         <xsl:when test="$outputNewMbhModel">
            <xsl:apply-templates select="$adaXmlWithBouwstenen"
                                 mode="flattenMbhModel"/>
         </xsl:when>
         <xsl:otherwise>
            <xsl:copy-of select="$adaXmlWithBouwstenen"/>
         </xsl:otherwise>
      </xsl:choose>
   </xsl:template>
   <!-- ============================================================ -->
   <!-- Flatten oud MBH wrapper model naar per-bouwsteen MBH model -->
   <!-- ============================================================ -->
   <xsl:template match="node() | @*"
                 mode="flattenMbhModel">
      <xsl:param name="mbhId"
                 as="element(identificatie)?"/>
      <xsl:copy>
         <xsl:apply-templates select="@*"
                              mode="flattenMbhModel"/>
         <xsl:apply-templates select="node()"
                              mode="flattenMbhModel">
            <xsl:with-param name="mbhId"
                            select="$mbhId"/>
         </xsl:apply-templates>
      </xsl:copy>
   </xsl:template>
   <!-- verwijder wrapper en geef MBH identificatie door -->
   <xsl:template match="medicamenteuze_behandeling"
                 mode="flattenMbhModel">
      <xsl:variable name="thisMbhId"
                    select="identificatie[1]"
                    as="element(identificatie)?"/>
      <xsl:apply-templates select="node()[not(self::identificatie)]"
                           mode="flattenMbhModel">
         <xsl:with-param name="mbhId"
                         select="$thisMbhId"/>
      </xsl:apply-templates>
   </xsl:template>
   <!-- voeg MBH-id toe aan bouwblokken -->
   <xsl:template match="medicatieafspraak | wisselend_doseerschema | verstrekkingsverzoek | toedieningsafspraak | medicatieverstrekking | verstrekking | medicatiegebruik | medicatietoediening"
                 mode="flattenMbhModel">
      <xsl:param name="mbhId"
                 as="element(identificatie)?"/>
      <xsl:copy>
         <xsl:apply-templates select="@*"
                              mode="flattenMbhModel"/>
         <xsl:apply-templates select="identificatie"
                              mode="flattenMbhModel"/>
         <xsl:if test="$mbhId and not(medicamenteuze_behandeling_id)">
            <medicamenteuze_behandeling_id>
               <xsl:copy-of select="$mbhId/@*"/>
            </medicamenteuze_behandeling_id>
         </xsl:if>
         <xsl:apply-templates select="node()[not(self::identificatie)]"
                              mode="flattenMbhModel">
            <xsl:with-param name="mbhId"
                            select="$mbhId"/>
         </xsl:apply-templates>
      </xsl:copy>
   </xsl:template>
</xsl:stylesheet>