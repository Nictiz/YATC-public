# Nictiz distribution MP9-Medicatieproces-9.3.0 1.0.2

Distribution: MP9-Medicatieproces-9.3.0

Version: 1.0.2, gebaseerd op MP9 3.0.0-beta.3

Wijzigingen tov distributie 1.0.1:
- MP-1567 (copy/@select)
- Geef voorrang aan zorgverlener als auteur, als zorgaanbieder ook ingevuld is
- toedieningssnelheid dataset aanpassing in beta.3 (en nodige fixes in de mappings daarvoor)
- verbetering tekst bij geannuleerd (alleen voor testgevallen / intern Nictiz)
- fix voor reden gebruik
- fix voor toedieningsweg

Created: 2024-05-01 09:51:16

This distribution was created by the YATC distribute component.

