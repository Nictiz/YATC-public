# Nictiz distribution MP9-Medicatieproces-9.3.0 1.0.4

Distribution: MP9-Medicatieproces-9.3.0

Version: 1.0.4, gebaseerd op MP9 3.0.0-beta.3

Wijzigingen tov distributie 1.0.3:
- MP-1681 (tijdzone conversie)

Created: 2024-11-07 16:21:00

This distribution was created by the YATC distribute component.

