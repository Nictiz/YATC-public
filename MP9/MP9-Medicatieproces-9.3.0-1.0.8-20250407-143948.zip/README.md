# Nictiz distribution MP9-Medicatieproces-9.3.0 1.0.8

Distribution: MP9-Medicatieproces-9.3.0

Version: 1.0.8, gebaseerd op MP9 3.0.0-beta.4

Wijzigingen tov distributie 1.0.7:
- MP-1853 Ondersteuning voor MP9-ada naar 6.12 HL7v3-vooraankonidiging voor hybride tests, zie ada_2_hl7\mp\6.12\sturen_medicatievoorschrift\payload

Created: 2025-04-07 14:39:48

This distribution was created by the YATC distribute component.

